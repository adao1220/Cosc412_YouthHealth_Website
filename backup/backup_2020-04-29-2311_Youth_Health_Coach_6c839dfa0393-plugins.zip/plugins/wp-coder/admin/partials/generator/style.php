<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
/* ========= INFORMATION ============================
	- document:  WP Coder!
	- author:    Dmytro Lobov 
	- url:       https://wow-estore.com/
==================================================== */
<?php echo $param['content_css'];?>