<?php if ( ! defined( 'ABSPATH' ) ) exit; 
	echo $param['content_js'];	
?>
