<div class="wrap" style="
     position: relative;
     margin: 25px 40px 0 20px;
     max-width: 1200px;"> 
  <?php $system->tables(); ?>
</div>