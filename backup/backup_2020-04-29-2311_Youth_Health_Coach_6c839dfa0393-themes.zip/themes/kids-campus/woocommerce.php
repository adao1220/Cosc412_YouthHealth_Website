<?php get_header(); ?>
<div class="container">
    	<div id="kc_content_wrap">
			<?php woocommerce_content(); ?>
		</div><!-- kc_content_wrap -->
</div><!-- container -->     
<?php get_footer(); ?>