<?php
/**
 * EduMag widgets inclusion
 *
 * This is the template that includes all custom widgets of EduMag
 *
 * @package Theme Palace
 * @subpackage EduMag
 * @since EduMag 0.1
 */

/*
 * Add social link widget
 */
require get_template_directory() . '/inc/widgets/social-link.php';