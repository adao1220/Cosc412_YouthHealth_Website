=== Business Owner ===

Contributors:       Mystery Themes Team
Requires at least:  WordPress 4.0
Tested up to:       WordPress 4.9
Requires PHP:       5.6
Stable tag:         1.0.1
License:            GPLv3 or later
License URI:        http://www.gnu.org/licenses/gpl-3.0.html
Tags:               one-column, two-columns, left-sidebar, right-sidebar, custom-colors, featured-images, sticky-post, translation-ready, blog, education, portfolio

== Description ==

Business Owner is is a child theme of Owner Multipurpose theme which is easy to use, highly customizable and well-designed Multi-Purpose Business Theme. Theme displays your site in the best possible way on smartphones, tablets, and laptops, as well as large desktop screens. The theme include many features that was most needed for the multipurpose theme. We have great customer support via email, support forum. View full Demo here: http://demo.mysterythemes.com/child-theme/business-owner/ | Support: https://mysterythemes.com/support/forum/themes/free-themes/

== Installation ==
	
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Copyright ==

Owner is distributed under the terms of the GNU GPL

Business Owner WordPress Theme is child theme of Owner, Copyright 2018 Mystery Themes
Business Owner is distributed under the terms of the GNU GPL

Owner bundles the following third-party resources:
 
    CounterUp Copyright 2013 Benjamin Intal
    Licenses: GPL
    https://github.com/bfintal/Counter-Up

    Screenshot images
    Licenses: CC0 Public Domain
    https://stocksnap.io/photo/0XI3PE0LIO

== Changelog ==

= 1.0.1 = 14th November 2019
	* Minor changes
	* Added requires php and requires at least version information
	* Reduced unwanted spacing
    * Comment form and spacing design tweaks done on single post pages.

= 1.0.0 = 20th April 2019
    * Initial release.